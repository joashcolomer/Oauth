const express = require('express');
const authRoutes = require('./routes/auth-routes');

const app = express();

//set up view engine
app.set('view engine', 'ejs');

//create home routes
app.get('/auth', authRoutes);
    res.render('home');
});
app.listen(3000, () => {
  
    console.log('app now listening for requests on port 3000');
});